from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier

app = Flask(__name__)

# Carregar o modelo para Claim Injury Type
CLAIM_MODEL_PATH = 'model/xgb_claim.pkl'
claim_model = joblib.load(CLAIM_MODEL_PATH)

# Carregar o modelo para Agreement Reach
AGREEMENT_MODEL_PATH = 'model/cat_grid.cbm'
agreement_model = CatBoostClassifier()
agreement_model.load_model(AGREEMENT_MODEL_PATH)



# Mapeamento das classes numéricas para Claim Injury Type
label_mapping = {
    0: "1. CANCELLED",
    1: "2. NON-COMP",
    2: "3. MED ONLY",
    3: "4. TEMPORARY",
    4: "5. PPD SCH LOSS",
    5: "6. PPD NSL",
    6: "7. PTD",
    7: "8. DEATH"
}

# Mapeamento das classes para Agreement Reach
label_mapping_ar = {
    0: "0. No Agreement",
    1: "1. Yes Agreement"
}

# Features do modelo para Claim Injury Type
claim_features = ["Accident Date","Age at Injury","Attorney/Representative",
    "Average Weekly Wage","Birth Year","C-2 Date","C-3 Date","Carrier Name",
    "Carrier Type","County of Injury","COVID-19 Indicator","District Name",
    "First Hearing Date","Gender","IME-4 Count","Industry Code","Medical Fee Region",
    "WCIO Cause of Injury Code","WCIO Nature of Injury Code","WCIO Part Of Body Code",
    "COVID_Industry"
]
# Features do modelo para Agreement Reach
agreement_features = [
    'Accident Date', 'Age at Injury', 'Alternative Dispute Resolution',
    'Attorney/Representative', 'Average Weekly Wage', 'C-2 Date',
    'C-3 Date', 'Carrier Name', 'Carrier Type', 'County of Injury',
    'District Name', 'First Hearing Date', 'Gender', 'IME-4 Count',
    'Industry Code', 'Medical Fee Region', 'WCIO Cause of Injury Code',
    'WCIO Nature of Injury Code', 'WCIO Part Of Body Code',
    'COVID_Industry'
]

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/main")
def main():
    return render_template("main.html")  # Página principal

# Rota para a página agreement.html
@app.route("/ag")
def agreement():
    return render_template("ag.html")

@app.route("/predict_claim", methods=['POST'])
def predict_claim():
    try:
        # Recebe os dados do frontend
        data = request.get_json()
        print("Dados recebidos para Claim Injury Type:", data)
        inputs = np.array(data['input'], dtype=np.float64)
        print("Inputs convertidos:", inputs)

        # Cria um DataFrame com os dados para passar ao modelo
        inputs_df = pd.DataFrame([inputs], columns=claim_features)

        # Realiza a previsão
        prediction = claim_model.predict(inputs_df)[0]

        # Mapeia a previsão para o rótulo correspondente
        prediction_label = label_mapping.get(prediction, 'Unknown')

        print(f"Previsão Claim Injury Type: {prediction_label}")
        return jsonify({"prediction": prediction_label})
    except Exception as e:
        print("Erro no backend para Claim Injury Type:", str(e))
        return jsonify({"error": str(e)})

@app.route("/predict_agreement", methods=['POST'])
def predict_agreement():
    try:
        # Recebe os dados do frontend
        data = request.get_json()
        print("Dados recebidos para Agreement Reach:", data)
        inputs = np.array(data['input'], dtype=np.float64)
        print("Inputs convertidos:", inputs)

        # Cria um DataFrame com os dados para passar ao modelo
        inputs_df = pd.DataFrame([inputs], columns=agreement_features)

        # Realiza a previsão
        prediction = agreement_model.predict(inputs_df)[0]

        # Mapeia a previsão para o rótulo correspondente
        prediction_label = label_mapping_ar.get(int(prediction), 'Unknown')

        print(f"Previsão Agreement Reach: {prediction_label}")
        return jsonify({"prediction": prediction_label})
    except Exception as e:
        print("Erro no backend para Agreement Reach:", str(e))
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)